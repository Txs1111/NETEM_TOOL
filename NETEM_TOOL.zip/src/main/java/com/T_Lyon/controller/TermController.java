package com.T_Lyon.controller;

import com.T_Lyon.pojo.Lead_User;
import com.T_Lyon.pojo.Term;
import com.T_Lyon.service.LeadService;
import com.T_Lyon.service.TermService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * 2021年7月12日09:20:10
 *
 * @author Lyon
 */

@Controller
@RequestMapping("/NETEM")
public class TermController {
    @Autowired
    private TermService termService;
    @Autowired
    private LeadService leadService;

    @RequestMapping("/lead")
    public String get3Term(Model model) {
        List<Term> terms = termService.get3Term();
        model.addAttribute("terms", terms);
        List<Lead_User> aim = leadService.getAim();
        List<Lead_User> boom = leadService.getBoom();
        List<Lead_User> exp = leadService.getEXP();
        model.addAttribute("aim", aim);
        model.addAttribute("boom", boom);
        model.addAttribute("exp", exp);
        return "NETM_lead";
    }

    @RequestMapping("/term")
    public String allTerm(Model model) {
        List<Term> allTerms = termService.getAllTerm();
        model.addAttribute("allTerms", allTerms);
        return "NETM_lead_term";
    }


    @RequestMapping("/oneterm/{id}")
    public String aTerm(@PathVariable int id, Model model) {
        Term oneTerm = termService.getOneTerm(id);
        model.addAttribute("oneTerm", oneTerm);
        return "NETM_lead_term";
    }

}
