package com.T_Lyon.controller;

import com.T_Lyon.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Random;

/**
 * 2021年7月9日11:46:49
 *
 * @author Lyon
 */

@Controller
//@RequestMapping("/")
public class aaa {
    @Autowired
//    @Qualifier("TestServiceImp")
    private TestService testService;

    @RequestMapping("/a1")
    public String a(Model model) {
        testService.test1();
        ArrayList<Integer> integers = new ArrayList<Integer>();
        Random random = new Random();
        int i = random.nextInt(2)+1;
        int i2 = random.nextInt(2)+1;
        integers.add(i);
        integers.add(i2);
        System.out.println(integers.size());
        return "a";
    }

    @RequestMapping("/index")
    public String index(Model model) {
        return "forward:/index.jsp";
    }
    @RequestMapping("/NETM_communication")
    public String NETM_communication(Model model) {
        return "NETM_communication";
    }
    @RequestMapping("/NETM_community_inf")
    public String NETM_community_inf(Model model) {
        return "NETM_community_inf";
    }
    @RequestMapping("/NETM_community_QA")
    public String NETM_community_QA(Model model) {
        return "NETM_community_QA";
    }
    @RequestMapping("/NETM_community_resource")
    public String NETM_community_resource(Model model) {
        return "NETM_community_resource";
    }
    @RequestMapping("/NETM_information")
    public String NETM_information(Model model) {
        return "NETM_information";
    }
    @RequestMapping("/NETM_information_admission")
    public String NETM_information_admission(Model model) {
        return "NETM_information_admission";
    }
    @RequestMapping("/NETM_information_mark")
    public String NETM_information_mark(Model model) {
        return "NETM_information_mark";
    }
    @RequestMapping("/NETM_information_outline")
    public String NETM_information_outline(Model model) {
        return "NETM_information_outline";
    }
    @RequestMapping("/NETM_information_rank")
    public String NETM_information_rank(Model model) {
        return "NETM_information_rank";
    }
    @RequestMapping("/NETM_information_real")
    public String NETM_information_real(Model model) {
        return "NETM_information_real";
    }
    @RequestMapping("/NETM_information_teacher")
    public String NETM_information_teacher(Model model) {
        return "NETM_information_teacher";
    }
    @RequestMapping("/NETM_lead")
    public String NETM_lead(Model model) {
        return "NETM_lead";
    }
    @RequestMapping("/NETM_lead_term")
    public String NETM_lead_term(Model model) {
        return "NETM_lead_term";
    }
    @RequestMapping("/NETM_mark")
    public String NETM_mark(Model model) {
        return "NETM_mark";
    }
    @RequestMapping("/NETM_send_post")
    public String NETM_send_post(Model model) {
        return "NETM_send_post";
    }
    
    
    
    
}
