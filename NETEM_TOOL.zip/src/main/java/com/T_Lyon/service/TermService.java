package com.T_Lyon.service;

import com.T_Lyon.pojo.Lead;
import com.T_Lyon.pojo.Term;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;


/**
 * 2021年7月10日12:41:35
 *
 * @author Lyon
 */
public interface TermService {
    /**
     * 获取所有标签
     *
     * @return
     */
    List<Term> getAllTerm();

    /**
     * 获取一个术语
     *
     * @return
     */
    Term getOneTerm(int id);


    /**
     * 获取三个术语
     *
     * @return
     */
    List<Term> get3Term();
}
