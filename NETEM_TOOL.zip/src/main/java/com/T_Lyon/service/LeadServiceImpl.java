package com.T_Lyon.service;

import com.T_Lyon.mapper.LeadMapper;
import com.T_Lyon.pojo.Lead_User;

import java.util.List;

public class LeadServiceImpl implements LeadService {
    private LeadMapper leadMapper;

    public void setLeadMapper(LeadMapper leadMapper) {
        this.leadMapper = leadMapper;
    }

    public List<Lead_User> getAim() {
        return leadMapper.getAim(0, 2);
    }

    public List<Lead_User> getBoom() {
        return leadMapper.getBoom(0, 2);
    }

    public List<Lead_User> getEXP() {
        return leadMapper.getEXP(0, 2);
    }
}
