package com.T_Lyon.service;

import com.T_Lyon.mapper.TermMapper;
import com.T_Lyon.pojo.Term;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 2021年7月12日09:23:11
 *
 * @author Lyon
 */
public class TermServiceImpl implements TermService {
    private TermMapper termMapper;
    static int amount = -1;

    public void setTermMapper(TermMapper termMapper) {
        this.termMapper = termMapper;
    }

    /**
     * 生成所有标签
     *
     * @return
     */
    public List<Term> getAllTerm() {
        List<Term> terms = new ArrayList<Term>();
        terms = termMapper.getAllTerm();
        amount = terms.size();
        return terms;
    }

    /**
     * 查询一个标签
     *
     * @param id
     * @return
     */
    public Term getOneTerm(int id) {
        return termMapper.getOneTerm(id);
    }

    /**
     * 生成随机三个标签
     *
     * @return
     */
    public List<Term> get3Term() {
        if (amount == -1) {
            List<Term> terms = new ArrayList<Term>();
            terms = termMapper.getAllTerm();
            amount = terms.size();
        }
        Random random = new Random();
        int random1 = random.nextInt(amount) + 1;
        int random2, random3;
        do {
            random2 = random.nextInt(amount) + 1;
        } while (random1 == random2);
        do {
            random3 = random.nextInt(amount) + 1;
        } while (random3 == random2 || random1 == random3);

        System.out.println("++++++++++++" + random1 + random2 + random3);
        return termMapper.get3Term(random1, random2, random3);
    }

}
