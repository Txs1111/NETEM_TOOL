package com.T_Lyon.service;

import com.T_Lyon.pojo.Lead_User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 2021年7月12日15:14:23
 *
 * @author Lyon
 */
public interface LeadService {
    /**
     * 获取考研目的部分内容
     *
     * @return
     */
    List<Lead_User> getAim();

    /**
     * 获取考研雷区部分内容
     *
     * @return
     */
    List<Lead_User> getBoom();

    /**
     * 获取考研经验部分内容
     *
     * @return
     */
    List<Lead_User> getEXP();
}
