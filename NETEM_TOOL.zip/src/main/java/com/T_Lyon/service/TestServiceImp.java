package com.T_Lyon.service;

import com.T_Lyon.mapper.TestMapper;
import com.T_Lyon.pojo.User;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 2021年7月8日16:00:41
 *
 * @author Lyon
 */
public class TestServiceImp implements TestService {

    private TestMapper testMapper;

    public void setTestMapper(TestMapper testMapper) {
        this.testMapper = testMapper;
    }

    public List<User> test1() {
        return testMapper.test();
    }
}
