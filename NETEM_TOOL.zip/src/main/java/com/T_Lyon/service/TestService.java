package com.T_Lyon.service;

import com.T_Lyon.pojo.User;

import java.util.List;

/**
 * 2021年7月8日15:58:31
 *
 * @author Lyon
 */
public interface TestService {

    /**
     * 2021年7月8日16:10:38
     * 测试
     *
     * @return
     */
    List<User> test1();
}
