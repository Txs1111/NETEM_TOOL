package com.T_Lyon.mapper;

import com.T_Lyon.pojo.User;

import java.util.List;

/**
 * 2021年7月8日15:42:07
 * @author Lyon
 */

public interface TestMapper {
    /**
     * 测试
     * @return
     */
    public List<User> test();
}
