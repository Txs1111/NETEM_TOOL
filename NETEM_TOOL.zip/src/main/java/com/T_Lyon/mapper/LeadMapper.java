package com.T_Lyon.mapper;

import com.T_Lyon.pojo.Lead_User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Date;
import java.util.List;

/**
 * 2021年7月12日15:03:05
 *
 * @author Lyon
 */
public interface LeadMapper {


    /**
     * 获取考研目的部分内容
     *
     * @param prefix
     * @param suffix
     * @return
     */
    @Select("select l.ID,l.type,l.userId,l.content,l.time,l.likes,u.name from stuma_netem_lead l, stuma_netem_user u " +
            "where type=1 and l.userId=u.studentCode1 limit #{prefix},#{suffix}")
    List<Lead_User> getAim(@Param("prefix") int prefix, @Param("suffix") int suffix);

    /**
     * 获取考研雷区部分内容
     *
     * @param prefix
     * @param suffix
     * @return
     */
    @Select("select l.ID,l.type,l.userId,l.content,l.time,l.likes,u.name from stuma_netem_lead l, stuma_netem_user u " +
            "where type=2 and l.userId=u.studentCode1 limit #{prefix},#{suffix}")
    List<Lead_User> getBoom(@Param("prefix") int prefix, @Param("suffix") int suffix);

    /**
     * 获取考研经验部分内容
     *
     * @param prefix
     * @param suffix
     * @return
     */
    @Select("select l.ID,l.type,l.userId,l.content,l.time,l.likes,u.name from stuma_netem_lead l, stuma_netem_user u" +
            " where type=3 and l.userId=u.studentCode1 limit #{prefix},#{suffix}")
    List<Lead_User> getEXP(@Param("prefix") int prefix, @Param("suffix") int suffix);

    @Insert("insert into stuma_netem_lead(ID,type,userId,content,time) values(#{ID},#{type},#{userId},#{content},#{time})")
    int addlead(@Param("ID") int ID, @Param("ID")int type, @Param("ID")String userId, @Param("ID")String content, @Param("ID")Date time);
}
