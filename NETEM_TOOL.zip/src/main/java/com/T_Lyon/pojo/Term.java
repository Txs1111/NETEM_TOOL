package com.T_Lyon.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 2021年7月12日09:09:57
 *
 * @author Lyon
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Term {
    /**
     * 主键
     */
    int ID;
    /**
     * 标签名
     */
    String name;
    /**
     * 标签解释
     */
    String content;
    /**
     * 添加时间
     */
    Date addTime;
}
