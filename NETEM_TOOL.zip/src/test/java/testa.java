import com.T_Lyon.pojo.User;
import com.T_Lyon.service.TestService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class testa {
    @Test
   public void te(){
        ApplicationContext content = new ClassPathXmlApplicationContext("applicationContext.xml");
        TestService testServiceImp = (TestService) content.getBean("TestServiceImp");
        for (User user :
                testServiceImp.test1()) {
            System.out.println(user);
        }
    }
}
