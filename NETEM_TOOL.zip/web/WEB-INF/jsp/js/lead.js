$(document).ready(function(){
	$(".leafing_button").click(function(){
		
		$("body").css({"background-color":"#CDCDCD"});
		$(".aim_post").show();
		// $(".cover_aim_block").show();
		
		
	});
	$(".go_out img").click(function(){
		$("body").css("background-color","#FFFFFF");
		$(".aim_post").hide();
	})
	$(".aim, .icon_aim").click(function(){
		$(".show_aims").show();
		$(".button_forAimPost").show();
		$(".show_bombs, .show_lessons").hide();
		$(".button_forBombPost").hide();
		$(".button_forLessonPost").hide();
		
	})
	$(".bomb, .icon_bomb").click(function(){
		$(".show_bombs").show();
		$(".button_forBombPost").show();
		$(".show_aims, .show_lessons").hide();
	    $(".button_forAimPost").hide();
		$(".button_forLessonPost").hide();
	})
	$(".lesson, .icon_lesson").click(function(){
		$(".show_lessons").show();
		$(".button_forLessonPost").show();
		$(".show_bombs, .show_aims").hide();
		$(".button_forAimPost").hide();
		$(".button_forBombPost").hide();
	})
	
})
